<?php
/**
 * @file
 * HTML markup.
 */
?>

<a href="http://github.com/<?php echo $username; ?>">
  <img style="position: absolute; top: 0; <?php echo $placement; ?>: 0; border: 0;"
    src="<?php echo $image_url; ?>" alt="Fork me on GitHub"/>
</a>
