<?php

/**
 * @file
 * Hooks provided by the sharerich.
 */

/**
 * Alter the sharerich buttons markup.
 *
 * @param array $buttons
 * @param object $node
 */
function hook_sharerich_buttons_alter(&$buttons, $context) {

}
