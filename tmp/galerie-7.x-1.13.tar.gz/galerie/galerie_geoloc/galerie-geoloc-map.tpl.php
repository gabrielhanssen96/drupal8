<div id="node-<?php echo $node->nid ?>" class="galerie-geoloc galerie-<?php echo $galerie_type ?>">
  <div id="galerie-geoloc-map"></div>
  <div id="galerie-geoloc-map-preview" class="galerie-browser-wrapper"><div class="galerie-browser"></div></div>
  <div id="galerie-geoloc-map-preview-quicksand" class="galerie-browser"></div>
</div>
